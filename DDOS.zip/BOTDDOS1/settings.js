const settings = {
  token: '6859880538:AAHCviDRt3Ma_gts5nvyTWnDckPSuX2_Qfo', //Token Bot
  adminId: '5945548890', //ID Kalian
  groupId: '-4182911063',
  urladmin: 'https://t.me/AnakManis1',
  menuUrl: 'https://t.me/AnakManis1',
  groupUrl: 'https://t.me/ghostxddos',
  chanelUrl: 'https://t.me/GXDDoS',
  adminteks: 'KAMU MENCARI ADMIN SAYA?\nTENTU INI ADALAH ADMIN SAYA:\nhttps://t.me/AnakManis1 : @AnakManis1'
};

module.exports = {
  ...settings,
  domain: 'kiicodeofficial.my.id',
  apikeys: {
    blackbox: '3wezRae6AZ',
    openai: '3wezRae6AZ'
  }
};